<?php
$servername ="localhost";
$username= "root";
$password= "Password@123";
$dbname = "certbuild";
$conn = mysqli_connect($servername, $username, $password,$dbname );
if ($conn->connect_error) {
    die("Connection failed: ");
}	/*
exec('sudo setenforce 0');*/


/*$temp = 'sudo setenforce 0';
echo $temp . "<br />";
$test = shell_exec($temp);
echo $test;*/
?>
