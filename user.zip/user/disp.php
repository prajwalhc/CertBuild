<!DOCTYPE html>
<html>
<head>
  <title>CertBuilder</title>

</head>
<style type="text/css">


	.bg {
    /* The image used */
    background-image: url("../img/background7.jpg");

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
</style>


<body class="bg">
    <?php 
include('navbar.php');
 ?>
 <div class="row">
<?php

$design=$_GET['design'];

for ($i=1; $i <100; $i++) { 
  if($design==sp.$i)
  {
    ?>
    <div align="center" class="col-sm-6"><a href="samsport.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
    <?php
    $selected=$design;
    break;
  }
  elseif ($design==cul.$i) {
    ?>
    <div align="center" class="col-sm-6"><a href="samcul.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
    <?php
    $selected=$design;
    break;

  }
  elseif ($design==course.$i) {
    ?>
    <div align="center" class="col-sm-6"><a href="samcourse.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
    <?php
    $selected=$design;
    break;
  }
  elseif ($design==bestout.$i) {
    ?>
    <div align="center" class="col-sm-6"><a href="sambestout.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
    <?php
    $selected=$design;
    break;
  }
  elseif ($design==other.$i) {
    ?>
    <div align="center" class="col-sm-6"><a href="samother.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
    <?php
    $selected=$design;
    break;
  }
}

 ?>

  <div align="center" class="col-sm-6"><a href="design.php"><p><button class="btn btn-success btn-lg">Change design</button></p></a></div>
 </div>
<div class="container" style="border:solid thin black;border-radius: 10px;">
  <h2 class="well well-sm" style="background-color:transparent; animation-duration: 3s;text-shadow:1px 1px 0 #444;"><b>Participants Details</b></h2><br>
  <!-- <div style="animation-duration: 3s;" class="w3-animate-zoom">-->
	<div class="table-responsive w3-animate-zoom">
	<table class="table table-striped">
		<thead>
			<tr>
				<th></th>
				<th style="color: #FF69B4;"><b>USN</b></th>
				<th  style="color: #FF69B4;"><b>Name</b></th>
				<th style="color: #FF69B4;"><b>Father</b></th>
				<th style="color:#FF69B4;"><b>Phone</b></th>
				<th  style="color: #FF69B4;"><b>Gender</b></th>
				<th  style="color: #FF69B4;"><b>Email</b></th>
				<th  style="color: #FF69B4;"><b>Branch</b></th>
				<th  style="color: #FF69B4;"><b>Year</b></th>
				<th  style="color: #FF69B4;"><b>College</b></th>
				<th  style="color: #FF69B4;"><b>Grade</b></th>
				<th  style="color: #FF69B4;"><b>Event</b></th>
				<th  style="color: #FF69B4;"><b>Rank</b></th>
			</tr>
			<tbody style="background-color: transparent;">
			<?php 
				include('database.php');

				$sql="select * from participant";
				$result=mysqli_query($conn, $sql);
				if ($result-> num_rows >0) {

					while ($row= $result-> fetch_assoc()) {
						echo "<tr style='background-color:transparent;'><td><form class='form-horizontal' action='checkbox.php' method='post'><div class='from-group'><input type=\"checkbox\" name='check[]' value='".$row["usn"]."'></div></td><td>".$row["usn"]."</td><td>".$row["name"]."</td><td>".$row["father"]."</td><td>".$row["phone"]."</td><td>".$row["gender"]."</td><td>".$row["email"]."</td><td>".$row["branch"]."</td><td>".$row["year"]."</td><td>".$row["college"]."</td><td>".$row["grade"]."</td><td>".$row["event"]."</td><td>".$row["prize"]."</td><td><a href='update.php?usn=".$row["usn"]."' style='color:blue;'><span class='glyphicon glyphicon-pencil' style='font-size:19px;'></span></a></td><td><a onClick=\"javascript: return confirm('Please confirm deletion');\" href='delete.php?usn=".$row["usn"]."' style='color:red'><span class='glyphicon glyphicon-trash' style='font-size:19px;'></span></a></td></tr>";
					}

					echo "</table>";
          echo "<div class=\"container-fluid\" align=\"center\"><button type=\"submit\" class=\"btn btn-success btn-lg\" name=\"submit\">Submit</button>
      </div>";
  echo "</form>";

				}
				else
				{
					echo "0 result";
				}
				$conn-> close();
			 
			 ?>
      

		</thead>
		</tbody>
	</table>
	</div>
</div>
</body>
</html>
