<!DOCTYPE html>
<html>
<head>

	<title>CertificateBuilder</title>
	<style type="text/css">
		.centered {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}
.container {
    position: relative;
    text-align: center;
    color: white;
}

body, html {
    height: 100%;
    margin: 0;
}

.bg {
    /* The image used */
    background-image: url("../img/background10.jpg");

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    background-attachment: fixed;
}
.form-inline > * {
   margin:25px 10px;
}

.image-preview-input-title {
    margin-left:2px;
}


/*
.image-preview-input input[type=file] {
  position: absolute;
  top: 0;
  right: 0;
  margin: 0;
  padding: 0;
  font-size: 20px;
  cursor: pointer;
  opacity: 0;
  filter: alpha(opacity=0);
}*/
.image-preview-input {
    position: relative;
  overflow: hidden;
  margin: 0px;    
    color: #333;
    background-color: #fff;
    border-color: #ccc;    
}
.content {
    max-width: 60%;
    margin: auto;
  /*  background: transparent;*/
    padding: 10px;
     height: 100%; 

	</style>
  <script src="script.js"></script>
</head>

<body class="bg">
<?php 
include('navbar.php');
?>
 <div class="row">
<?php

$design=$_GET['design'];

for ($i=1; $i <100; $i++) { 
  if($design==sp.$i)
  {
    ?>
    <div align="center" class="col-sm-6"><a href="samsport.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
    <?php
    $selected=$design;
    break;
  }
  elseif ($design==cul.$i) {
    ?>
    <div align="center" class="col-sm-6"><a href="samcul.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
    <?php
    $selected=$design;
    break;

  }
  elseif ($design==course.$i) {
    ?>
    <div align="center" class="col-sm-6"><a href="samcourse.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
    <?php
    $selected=$design;
    break;
  }
  elseif ($design==bestout.$i) {
    ?>
    <div align="center" class="col-sm-6"><a href="sambestout.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
    <?php
    $selected=$design;
    break;
  }
  elseif ($design==other.$i) {
    ?>
    <div align="center" class="col-sm-6"><a href="samother.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
    <?php
    $selected=$design;
    break;
  }
}

 ?>

  <div align="center" class="col-sm-6"><a href="design.php"><p><button class="btn btn-success btn-lg">Change design</button></p></a></div>
 </div>

 <div class="alert alert-success" align="center">
      <strong><a href="disp.php?design=<?php echo "$selected";?>">click here </a></strong>If data is already is present.
   
  </div>


 <div style="background:transparent !important;border:solid thin black;border-radius: 10px;" class="container-fluid" align="center">

  <h1 style="color: #ffffff">ADD PARTICIPANTS</h1>
  <p style="color: #000000"><b>Enter Participant Details</b></p>
</div><br>
<div class="content" style="opacity: 0.7;"><br><br>
<form  class="form-horizontal w3-animate-zoom" action="insertdata.php" method="POST">
    <div class="form-group">
        <label class="control-label col-sm-2" for="usn">USN or ID:</label>
        <div class="col-sm-9"> 
            <input type="text" name="usn" class="form-control" id="usn" placeholder="Enter USN or ID" value="" required="">
        </div>
    </div><br>
 <div class="form-group">
 <label class="control-label col-sm-2" for="name">Name:</label> 
 
     <div class="col-sm-9">
      <input type="text" name="name" class="form-control" id="name" placeholder="Enter Your Name" value="" required=""> 
     </div>
 </div><br>

 <div class="form-group">
 <label class="control-label col-sm-2" for="name">Gender:</label>
 <div class="col-sm-9"> 
  <label class="radio-inline">
      <input type="radio" name="gender" value="male" id="gender" required="">Male
    </label>
    <label class="radio-inline">
      <input type="radio" name="gender" value="female" id="gender" required="">Female
    </label>
   
    </div>
 </div><br>

  <div class="form-group">
 <label class="control-label col-sm-2" for="father">Father Name:</label>
     <div class="col-sm-9">
      <input type="text" name="father" class="form-control" id="father" placeholder="Enter Your father name">
     </div>

 </div><br>
  <div class="form-group">
 <label class="control-label col-sm-2" for="phone">Phone Number:</label>
     <div class="col-sm-9">
      <input type="Number" name="phone" class="form-control" id="phone" placeholder="Enter Your Phone Number" value="" required="">
       
     </div>
 </div><br>
 <div class="form-group">
    <label class="control-label col-sm-2" for="email">Email:</label>
    <div class="col-sm-9">
      <input type="email" name="email" class="form-control" id="email" placeholder="Enter email" value="" required="">
    </div>
  </div><br>
  <div class="form-group">
 <label class="control-label col-sm-2" for="college">College:</label>
     <div class="col-sm-9">
      <input type="text" class="form-control" id="college" name="college" placeholder="Enter college name" value="" required=""> 
       
     </div>
 </div><br>

 <div class="form-group">
 <label class="control-label col-sm-2" for="college">sem:</label>
     <div class="col-sm-9">
      <input type="text" class="form-control" id="sem" name="sem" placeholder="Enter semester" value="" required=""> 
       
     </div>
 </div><br>
 <div class="form-group">
 <label class="control-label col-sm-2" for="branch">Branch:</label>
     <div class="col-sm-9">
<select name="branch" class="form-control" id="branch" required="">
  <option value="">Select</option>
  <option value="cse">CSE</option>
  <option value="ece">ECE</option>
  <option value="mech">MECH</option>
  <option value="civil">CIVIL</option>
  <option value="eee">EEE</option>
</select>
 </div>
 </div><br>

<div class="form-group">
 <label class="control-label col-sm-2" for="year">Year:</label>
  <div class="col-sm-9">
    <input type="number" name="year" class="form-control" id="year" placeholder="Enter year Ex:2015" value="">
      </div>
 </div><br><br>

 <div class="form-group">
 <label class="control-label col-sm-2" for="grade">Grade:</label>
     <div class="col-sm-9">
      <input type="text" name="grade" class="form-control" id="grade" placeholder="Enter Your Grade Ex:A"> 
     </div>
 </div><br>

<div class="form-group">
 <label class="control-label col-sm-2" for="event">Event:</label>
     <div class="col-sm-9">
      <input type="text" name="event" class="form-control" id="event" placeholder="Enter Event" required="">
     </div>
 </div><br>

 <div class="form-group">
 <label class="control-label col-sm-2" for="rank" >Rank:</label>
     <div class="col-sm-9">
<select name="rank" class="form-control" id="rank" required="">
  <option value=""></option>
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
</select>
 </div>
 </div><br>
 <!-- <div class="form-group col-sm-7" align="center">
  <div class="btn btn-default image-preview-input ">
    <span class="glyphicon glyphicon-picture"></span>
    <span class="image-preview-input-title">Browse Photo</span>
    <input type="file" accept="image/png, image/jpeg, image/gif" name="input-file-preview"/>
  </div>
 </div>
 <div class="form-group" align="center" style="background-color: transparent;">
  <div class="btn btn-default image-preview-input">
    <span class="glyphicon glyphicon-pencil"></span>
    <span class="image-preview-input-title">Browse Signature</span>
    <input type="file" accept="image/png, image/jpeg, image/gif" name="input-file-preview"/>
  </div>
 </div> -->
 <div class="container-fluid" align="center">
     <button type="submit" class="btn btn-info btn-lg" name="submit"><span class="glyphicon glyphicon-send"></span> Submit</button>
 </div>
</form>
</div>
 </div>
</form>
</div>



</body>
</html>