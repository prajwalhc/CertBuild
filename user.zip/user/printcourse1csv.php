<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once("dompdf/autoload.inc.php");
use Dompdf\Dompdf;

// instantiate and use the dompdf class
/*include 'dompdf/dompdf_config.inc.php';
*/
include('database.php');

$query = "select * from csv";
$result = mysqli_query($conn, $query);
/*mkdir('certificates/certi', 0777, true);
*/
$path='certificates/certi/';
while(($row=mysqli_fetch_array($result)))
{
  $usn=$row['usn']; 
  $name=$row['name']; 
  $branch=$row['branch'];
  $grade=$row['grade'];
  $college=$row['college'];
  $year=$row['year'];
  $rank=$row['prize'];
  $sem=$row['sem'];

 if($rank==1)
  {
    $rapen="<sup>st</sup>";
  }
  else if($rank==2)
  {
   $rapen="<sup>nd</sup>";
   
  }
   else if($rank==3)
  {
   $rapen="<sup>rd</sup>";
    
  }
   else
  {
 $rapen="<sup>th</sup>";
    
 }


  if($sem==1)
  {
    $sapen="<sup>st</sup>";
  }
  else if($sem==2)
  {
   $sapen="<sup>nd</sup>";
   
  }
   else if($sem==3)
  {
   $sapen="<sup>rd</sup>";
    
  }
   else
  {
 $sapen="<sup>th</sup>";  
 }
  
  $event=$row['event'];

  if ( get_magic_quotes_gpc() )
      $old_limit = ini_set("memory_limit", "16M");

    $dompdf = new Dompdf();

$html='
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="css/w3.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/jquery.js"></script>
  <style type="text/css">

@page {
    size: A4 landscape;
    margin: 72px 76px;
  }
  .back
  {
   background-image: url("../img/backgroundcerti1.jpg");
    /*height:auto;
    background-size: 100%;
  background-position: center; 
  position: relative;*/
  background-repeat: no-repeat;
  }

</style>
</head>
<body>
 <p style="float: left;padding-left: 13px">ref:gech_cert_'.$usn.'</p>
<div class="container-fluid back" style="padding:60px; text-align:center; border: 5px solid #787878;">

       <span style="font-size:50px; font-weight:bold">Certificate of Completion</span><br><br>

       <span style="font-size:25px"><i>This is to certify that</i></span>
       <br><br>
       <span style="font-size:30px"><b>'.$name.'</b></span><br/><br/>
       <span style="font-size:25px"><i>has completed the course <b>'.$branch.'</b></i></span> <br/><br/>
       <span style="font-size:20px">with score of <b>'.$grade.'</b></span> <br/><br/>
       <span style="font-size:23px"><i>from <b>'.$college.'<b></i></span><br><br>
      <span style="font-size:20px">in the academic year <b>'.$year.'</b></span><br><br><br>
       <div class="row">
  <div class="col-sm-5" style="font-size: 20px;float: left;"><b>Head of Department</b></div>
  <div class="col-sm-7"  style="font-size: 20px"><b>Principal</b></div>
</div>
</div>
</body>
</html>';

/*$html=file_get_contents("cert.html");*/
$dompdf->loadHtml($html);

// (Optional) Setup the paper size and orientation
$dompdf->setPaper('A4', 'landscape');
set_time_limit(50000);

// Render the HTML as PDF
$dompdf->render();

// Output the generated PDF to Browser
file_put_contents($path."$usn".$name.".pdf", $dompdf->output()); 
}


$zip = new ZipArchive;
$zip->open('certificates/myzip.zip', ZipArchive::CREATE);
foreach (glob("certificates/certi/*") as $file) {
    $zip->addFile($file);
}
$zip->close();

foreach (glob("certificates/certi/*") as $file) {
    unlink($file);
}

/*rmdir("certificates/certi/");*/
echo "all certificates generated <a href='certificates/myzip.zip'>download</a>";


?>
