<!DOCTYPE html>
<html>
<head>
	<title>DeleteCSV</title>

	<link rel="stylesheet" href="../../css/bootstrap.min.css">
  <link rel="stylesheet" href="../../css/w3.css">
  <script type="text/javascript" src="../../js/bootstrap.min.js"></script>
   <script type="text/javascript" src="../../js/jquery.min.js"></script>
</head>
<body>

</body>
</html>



<?php 
/*ini_set('display_errors', 1);
                error_reporting (E_ALL);*/
             include('database.php');

 if(isset($_GET['usn'])){
 			$usn=$_GET['usn'];
 			$sql = "delete from participant where usn='".$usn."'";
 			$res = mysqli_query($conn,$sql);
 			if($res) {
	?><br><br><br>
	<div class="alert alert-success">
  		<strong>Deleted!</strong>Successfully Loading......... Please Wait
		<meta http-equiv="refresh" content="3;url=disp.php" />
	</div>

	<?php
}
else {
	?>
	<br><br><br>
	<div class="alert alert-danger">
  		<strong>Sorry!</strong>Data not deleted
  		<meta http-equiv="refresh" content="2;url=disp.php" />
	</div>
	<?php
} 
 }
?>	