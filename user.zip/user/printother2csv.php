<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once("dompdf/autoload.inc.php");
use Dompdf\Dompdf;

// instantiate and use the dompdf class
/*include 'dompdf/dompdf_config.inc.php';
*/

include('database.php');

$query = "select * from csv";
$result = mysqli_query($conn, $query);
/*mkdir('certificates/certi', 0777, true);
*/
$path='certificates/certi/';
while(($row=mysqli_fetch_array($result)))
{
  $usn=$row['usn']; 
  $name=$row['name']; 
  $branch=$row['branch'];
  $grade=$row['grade'];
  $college=$row['college'];
  $year=$row['year'];
  $rank=$row['prize'];
  $sem=$row['sem'];
  $event=$row['event'];
 if($rank==1)
  {
    $rapen="<sup>st</sup>";
  }
  else if($rank==2)
  {
   $rapen="<sup>nd</sup>";
   
  }
   else if($rank==3)
  {
   $rapen="<sup>rd</sup>";
    
  }
   else
  {
 $rapen="<sup>th</sup>";
    
 }


  if($sem==1)
  {
    $sapen="<sup>st</sup>";
  }
  else if($sem==2)
  {
   $sapen="<sup>nd</sup>";
   
  }
   else if($sem==3)
  {
   $sapen="<sup>rd</sup>";
    
  }
   else
  {
 $sapen="<sup>th</sup>";  
 }
  
  $event=$row['event'];

  if ( get_magic_quotes_gpc() )
      $old_limit = ini_set("memory_limit", "16M");

    $dompdf = new Dompdf();

$html='
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="css/w3.css">
  <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
  <script type="text/javascript" src="../js/bootstrap.min.js"></script>
  <script type="text/javascript" src="../js/jquery.js"></script>
  <style type="text/css">

@page {
    size: A4 landscape;
   /* margin: 72px 76px;*/
  }
  .back
  {
   background-image: url("../img/glue4.png");
    background-size:100%;
  position: absolute;
  background-repeat: no-repeat;
  }
sup {
    vertical-align: super;
    font-size: smaller;
}
.footer {
   position: fixed;
   left: 120;
   bottom: 120;
   width: 100%;
  /* background-color: red;*/
 /*  color: white;*/
   text-align: center;
}
</style>
</head>
<body>
<div class="container-fluid back" style="padding:100px; text-align:center; border: 5px solid #787878;">
       

       <div class="row">
     <div class="col-sm-2"></div>
       <div style="padding-left:2%;padding-right: 4%;font-family: Arvo, serif;" class="col-sm-9">
       <br><br><br><br><br><br><br><br>
       <span style="font-size:25px;color: #05077d;  font-family: \' Times New Roman \', Times, serif;text-align:justify;"> <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; This is to certify that <b>&nbsp; <u>'.$name.'</u> </b> bearing USN <b><u>'.$usn.'</u></b> has Volunteered in the camp organized by <b>GECH Linux Users and Enthusiasts</b> in association with<b> Free Software Movement Karnataka</b> in  <b> <u>'.$event.'</u> </b>track, from<b> 21<sup>st</sup> March 2019</b> to <b> 24<sup>th</sup> March 2019</b>.</p></span> 
      </div>  
      <div class="col-sm-1"></div>     
       </div>
      <!--  <div class="row" style="font-size:20px;color: #05077d;font-family: Arvo, serif;">
  <div class="col-sm-3" style="font-size: 20px;text-align: justify;"><b></b></div>
  <div class="col-sm-4"  style="font-size: 22px;text-align: justify;"><img src="../img/shijil.png"></div>
  <div class="col-sm-4"  style="font-size: 22px;text-align: justify;"></div>
  <div class="col-sm-3" style="font-size: 20px;text-align: justify;"><b></b></div>
</div> -->
     <div class="footer">
       <div class="row" style="font-size:20px;color: #05077d;font-family: Arvo, serif;">
  <div class="col-sm-3" style="font-size: 20px;text-align: justify;"><b></b></div>
 
  <div class="col-sm-4"  style="font-size: 22px;text-align: justify;"><img src="../img/shijil.png"><br><b>Shijil T.V.<br><i style="font-size:">President<br>FSMK<b></div>

  <div class="col-sm-4"  style="font-size: 22px;text-align: justify;"><b><br><div style="height: 15px"></div>Dr. K.C. Ravishankar<br><i style="font-size:">Principal<br>GEC, Hassan<b></div>
  <div class="col-sm-1" style="font-size: 20px;text-align: justify;"><b></b></div>
</div><br><br>
</div>
</body>
</html>';

/*$html=file_get_contents("cert.html");*/
$dompdf->loadHtml($html);

// (Optional) Setup the paper size and orientation
$dompdf->setPaper('A4', 'landscape');
set_time_limit(50000);

// Render the HTML as PDF
$dompdf->render();

// Output the generated PDF to Browser
file_put_contents($path."$usn".$name.".pdf", $dompdf->output()); 
}


$zip = new ZipArchive;
$zip->open('certificates/myzip.zip', ZipArchive::CREATE);
foreach (glob("certificates/certi/*") as $file) {
    $zip->addFile($file);
}
$zip->close();

foreach (glob("certificates/certi/*") as $file) {
    unlink($file);
}

/*rmdir("certificates/certi/");*/
echo "all certificates generated <a href='certificates/myzip.zip'>download</a>";


?>
