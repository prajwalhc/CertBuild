<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once("dompdf/autoload.inc.php");
use Dompdf\Dompdf;

// instantiate and use the dompdf class
/*include 'dompdf/dompdf_config.inc.php';
*/

include('database.php');
$query = "select * from csv";
$result = mysqli_query($conn, $query);
/*mkdir('certificates/certi', 0777, true);
*/
$path='certificates/certi/';
while(($row=mysqli_fetch_array($result)))
{
  $usn=$row['usn']; 
  $name=$row['name']; 
  $branch=$row['branch'];
  $grade=$row['grade'];
  $college=$row['college'];
  $year=$row['year'];
  $rank=$row['prize'];
  $sem=$row['sem'];

 if($rank==1)
  {
    $rapen="<sup>st</sup>";
  }
  else if($rank==2)
  {
   $rapen="<sup>nd</sup>";
   
  }
   else if($rank==3)
  {
   $rapen="<sup>rd</sup>";
    
  }
   else
  {
 $rapen="<sup>th</sup>";
    
 }


  if($sem==1)
  {
    $sapen="<sup>st</sup>";
  }
  else if($sem==2)
  {
   $sapen="<sup>nd</sup>";
   
  }
   else if($sem==3)
  {
   $sapen="<sup>rd</sup>";
    
  }
   else
  {
 $sapen="<sup>th</sup>";  
 }
  
  $event=$row['event'];

  if ( get_magic_quotes_gpc() )
      $old_limit = ini_set("memory_limit", "16M");

    $dompdf = new Dompdf();

$html='
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="css/w3.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/jquery.js"></script>
 <!--  <link href="https://fonts.googleapis.com/css?family=Anton" rel="stylesheet"> -->
  <style type="text/css">


@page {
    size: A4 landscape;
   /* margin: 72px 76px;*/
   margin: 10mm 10mm 10mm 10mm;
  }
  .back
  {
   background-image: url("../img/background1.jpg");
    background-size:100%;
  position: absolute;
 background-repeat: repeat-x;
background-position: bottom left;
  /* z-index: -1;
   opacity: 0.5;*/
  }
sup {
    vertical-align: super;
    font-size: smaller;
}
.footer {
   position: fixed;
   left: 70;
   bottom: 135;
   width: 100%;
  /* background-color: red;*/
 /*  color: white;*/
   text-align: center;
}
.shana{
text-shadow:2px 2px  2px rgba(1, 96, 116, 1);
}
#watermark
{
  position: absolute;
  width: 100%;
  height:100%;
   /* margin: 72px 76px;*/
  /* margin: 10mm 10mm 10mm 10mm;*/
   z-index: -1;
   opacity: 0.5;
}
</style>
</head>
<body>
<!--  <div id="watermark">
  <img src="../img/grass78.png">
</div> -->

<div class="container-fluid back" style="padding:5px; text-align:center; border: 5px solid #787878;">
      
       <div align="center" style="">
       <div class="row">
       <div class="col-sm-2"><p style="float: left">ref-id:cert'.$usn.'</p></div>
     <div class="col-sm-3" align="center" style="width:210px"><img src="img/govtlogo.png" style="width: 100px;height: 100px;"></div>
     <div  class="col-sm-7"></div>
      </div>
      <span class="shana" style="font-size:19px; font-weight:bold;color: blue;">GOVERNMENT OF KARNATAKA</span><br>
      <span class="shana" style="font-size:19px; font-weight:bold;color: blue;">DEPARTMENT OF TECHNICAL EDUCATION</span><br>
      <span class="shana" style="font-size:30px; font-weight:bolder;color: red;font-family:Arial, Helvetica, sans-serif;">GOVERNMENT ENGINEERING COLLEGE</span><br>
      <span class="shana" style="font-size:17px; font-weight:bold;color: blue;"><i>HASSAN-573201</i></span>
       <br>   
      </div>


       <div class="row">
     <!-- <div class="col-sm-1"></div> -->
       <div style="padding-left:7%;padding-right: 7%;text-align: justify;" >
       <br><br><br><br><br><br>
       <span style="font-size:27px;text-align: justify;font-family: \' Times New Roman \', Times, serif;color: black;" ><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;This is to certify that<b>&nbsp;<u>'.$name.'</u> &nbsp;</b> of <b>&nbsp;<u>'.$sem.'</u>'.$sapen.'&nbsp;</b> Semester <b>&nbsp;<u>'.$branch.'</u> &nbsp;</b> branch has participated in <b>&nbsp; <u>'.$event.'</u>&nbsp;</b> Annual Sports  Competitions and Secured <b>&nbsp;<u>'.$rank.'</u>'.$rapen.'&nbsp;</b> place in the academic year<b>&nbsp;<u>'.$year.'</u></b>.</i></b></span>
      </div>  
<!--       <div class="col-sm-3"></div>     
 -->       </div>
      <!--  <div class="row" style="font-size:20px;color: #05077d;font-family: Arvo, serif;">
  <div class="col-sm-3" style="font-size: 20px;text-align: justify;"><b></b></div>
  <div class="col-sm-4"  style="font-size: 22px;text-align: justify;"><img src="../img/shijil.png"></div>
  <div class="col-sm-4"  style="font-size: 22px;text-align: justify;"></div>
  <div class="col-sm-3" style="font-size: 20px;text-align: justify;"><b></b></div>
</div> -->
     <div class="footer">
       <div class="row" style="font-family: \' Times New Roman \', Times, serif;text-align:justify;color: black;" align="center">
  <!-- <div class="col-sm-3" style="font-size: 20px;text-align: justify;"><b></b></div>
  -->
  <div class="col-sm-4"  style="text-align:;"><br><i style="font-size:"><b><font size="5">Asst. Director of PE<br>GEC, Hassan</font></b></i></div>

 <div class="col-sm-4"  style="text-align:;"><br><i style="font-size:"><b><font size="5">Student Welfare Officer<br>GEC, Hassan</font></b></i></div>

  <div class="col-sm-4"  style="text-align:;"><br><i style="font-size:"><b><font size="5">Principal<br>GEC, Hassan</font></b></i></div>
 <!--  <div class="col-sm-1" style="font-size: 20px;text-align: justify;"><b></b></div> -->
</div><br><br>
</div>
</div>

</body>
</html>';

/*$html=file_get_contents("cert.html");*/
$dompdf->loadHtml($html);

// (Optional) Setup the paper size and orientation
$dompdf->setPaper('A4', 'landscape');
set_time_limit(50000);

// Render the HTML as PDF
$dompdf->render();

// Output the generated PDF to Browser
file_put_contents($path."$usn".$name.".pdf", $dompdf->output()); 
}


$zip = new ZipArchive;
$zip->open('certificates/myzip.zip', ZipArchive::CREATE);
foreach (glob("certificates/certi/*") as $file) {
    $zip->addFile($file);
}
$zip->close();

foreach (glob("certificates/certi/*") as $file) {
    unlink($file);
}

/*rmdir("certificates/certi/");*/
echo "all certificates generated <a href='certificates/myzip.zip'>download</a>";


?>
