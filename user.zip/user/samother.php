<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once("dompdf/autoload.inc.php");

use Dompdf\Dompdf;

 $dompdf = new Dompdf();
for ($i=1; $i <100 ; $i++) { 
	if($i==$_GET['id'])
	{
$html=file_get_contents("designs/other/othercerti$i.html");
break;
}
}
$dompdf->loadHtml($html);
// (Optional) Setup the paper size and orientation
/*$customPaper = array(0,0,400,400);*/
$dompdf->setPaper('A4','landscape');

// Render the HTML as PDF
$dompdf->render();
$dompdf->stream("sample",array("Attachment"=>0));
?>