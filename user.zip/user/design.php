<!DOCTYPE html>
<html>
<head>
  <title>View/Select Design</title>
</head>

 <style type="text/css">
 	
/*#page-loader {
position: relative;
top: 0;
bottom: 0;
left: 0;
right: 0;
z-index: 10000;
display: none;
text-align: center;
width: 100%;
padding-top: 25px;
background-color: rgba(255, 255, 255, 0.7);
}*/
.bg{
    height: 100%; 
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    background-attachment: fixed;
    background-image: url("img/selectbg.jpg");
    padding-top: 8px;
}
 </style>

	
<body class="bg">

<?php 
include('navbar.php');
 ?>
 <!-- <div id="page-loader">
    <h3 style="color: green;">Loading page...</h3>  
</div> -->
<div align="center">
  <div style=";color: white;font-size: 35px"><b>Designs</b><br></div>


<!-- Sports certicates of different design can loaded here
 -->
  <div class="row">
  <h2 style="color: white;background-color: transparent;" class="well well-sm"><b>Sports Certificates</b></h2>
  <div class="card col-sm-3" style="border:solid thick black;border-radius: 10px;border-color: white;margin-left: 0px; margin-top: 8px">
  <img src="img/slogo.png" alt="loading" style="width:100px;height:90px" align="center">
  <h4 style="color: white"><b>Certificate_ID:1</b></h4>
 <div class="row">
<div class="col-sm-6"><a href="samsport.php?id=1"  onclick="javascript:document.getElementById('page-loader').style.display='block';" target="_blank"><p><button class="btn btn-primary btn-lg">view</button></p></a></div>
<div class="col-sm-6"><a href="selectdata.php?design=sp1" ><p><button class="btn btn-success btn-lg">select</button></p></a></div>
</div>
</div>



<div class="card col-sm-3" style="border:solid thick black;border-radius: 10px;border-color: white;margin-left: 0px; margin-top: 8px">
  <img src="img/slogo.png" alt="loading" style="width:100px;height:90px" align="center">
  <h4 style="color: white"><b>Certificate_ID:2</b></h4>
 <div class="row">
<div class="col-sm-6"><a href="samsport.php?id=2"  onclick="javascript:document.getElementById('page-loader').style.display='block';" target="_blank"><p><button class="btn btn-primary btn-lg">view</button></p></a></div>
<div class="col-sm-6"><a href="selectdata.php?design=sp2"><p><button class="btn btn-success btn-lg">select</button></p></a></div>
</div>
</div>
<!-- 
End of sports certificate section -->
</div>
</div><br>


<div align="center" class="row">
 <h2 style="color: white;background-color: transparent;" class="well well-sm" ><b>Cultural Certificates</b></h2>
  <div class="card col-sm-3" style="border:solid thick black;border-radius: 10px;border-color: white;margin-left: 0px; margin-top: 8px">
  <img src="img/clogo.png" alt="loading" style="width:100px;height:90px" align="center">
  <h4 style="color: white"><b>Certificate_ID:1</b></h4>
 <div class="row">
<div class="col-sm-6"><a href="samcul.php?id=1"  onclick="javascript:document.getElementById('page-loader').style.display='block';" target="_blank"><p><button class="btn btn-primary btn-lg">view</button></p></a></div>
<div class="col-sm-6"><a href="selectdata.php?design=cul1"><p><button class="btn btn-success btn-lg">select</button></p></a></div>
</div>
</div>

</div><br>


<div align="center" class="row">
 <h2 style="color: white;background-color: transparent;" class="well well-sm" ><b>Course Completion Certificates</b></h2>
  <div class="card col-sm-3" style="border:solid thick black;border-radius: 10px;border-color: white;margin-left: 0px; margin-top: 8px">
  <img src="img/cologo.png" alt="loading" style="width:100px;height:90px" align="center">
  <h4 style="color: white"><b>Certificate_ID:1</b></h4>
 <div class="row">
<div class="col-sm-6"><a href="samcourse.php?id=1"  onclick="javascript:document.getElementById('page-loader').style.display='block';" target="_blank"><p><button class="btn btn-primary btn-lg">view</button></p></a></div>
<div class="col-sm-6"><a href="selectdata.php?design=course1"><p><button class="btn btn-success btn-lg">select</button></p></a></div>
</div>
</div>

</div><br>

<div align="center" class="row">
 <h2 style="color: white;background-color: transparent;" class="well well-sm" ><b>Best Outgoing Student Certificates</b></h2>
  <div class="card col-sm-3" style="border:solid thick black;border-radius: 10px;border-color: white;margin-left: 0px; margin-top: 8px">
  <img src="img/cologo.png" alt="loading" style="width:100px;height:90px" align="center">
  <h4 style="color: white"><b>Certificate_ID:1</b></h4>
 <div class="row">
<div class="col-sm-6"><a href="sambestout.php?id=1"  onclick="javascript:document.getElementById('page-loader').style.display='block';" target="_blank"><p><button class="btn btn-primary btn-lg">view</button></p></a></div>
<div class="col-sm-6"><a href="selectdata.php?design=bestout1"><p><button class="btn btn-success btn-lg">select</button></p></a></div>
</div>
</div>

</div><br>

<div align="center" class="row">
 <h2 style="color: white;background-color: transparent;" class="well well-sm" ><b>Other Certificates</b></h2>


  <div class="card col-sm-3" style="border:solid thick black;border-radius: 10px;border-color: white;margin-left: 0px; margin-top: 8px">
  <img src="img/cologo.png" alt="loading" style="width:100px;height:90px" align="center">
  <h4 style="color: white"><b>Certificate_ID:1</b></h4>
 <div class="row">
<div class="col-sm-6"><a href="samother.php?id=1"  onclick="javascript:document.getElementById('page-loader').style.display='block';" target="_blank"><p><button class="btn btn-primary btn-lg">view</button></p></a></div>
<div class="col-sm-6"><a href="selectdata.php?design=other1"><p><button class="btn btn-success btn-lg">select</button></p></a></div>
</div>
</div>

  <div class="card col-sm-3" style="border:solid thick black;border-radius: 10px;border-color: white;margin-left: 0px; margin-top: 8px">
  <img src="img/cologo.png" alt="loading" style="width:100px;height:90px" align="center">
  <h4 style="color: white"><b>Certificate_ID:2</b></h4>
 <div class="row">
<div class="col-sm-6"><a href="samother.php?id=2"  onclick="javascript:document.getElementById('page-loader').style.display='block';" target="_blank"><p><button class="btn btn-primary btn-lg">view</button></p></a></div>
<div class="col-sm-6"><a href="selectdata.php?design=other2"><p><button class="btn btn-success btn-lg">select</button></p></a></div>
</div>
</div>

</div><br>

</body>
</html>