<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/w3.css">
  <script type="text/javascript" src="../js/bootstrap.min.js"></script>
   <script type="text/javascript" src="../js/jquery.min.js"></script>
</head>
<body>


<?php
	include('database.php');
	/*include('../bootlink.php');*/

ini_set('display_errors', 1);
                error_reporting (E_ALL);

if (isset($_POST['submit'])) {


$usn=strip_tags(($_POST["usn"]));
$name =strip_tags(($_POST["name"]));
$father =strip_tags(($_POST["father"]));
$gender =strip_tags(($_POST["gender"]));
$email =strip_tags(($_POST["email"]));
$sem=strip_tags(($_POST["sem"]));

$phone=strip_tags(($_POST["phone"]));
$college =strip_tags(($_POST["college"]));
$branch =strip_tags(($_POST["branch"]));
$year = strip_tags(($_POST["year"]));
$grade =strip_tags(($_POST["grade"]));
$event =strip_tags(($_POST["event"]));
$rank =strip_tags(($_POST["rank"]));


/*$query="insert into csv(usn,name,father,college,branch,year,grade,event,email,phone,gender,sem) values('".$usn."','".$name."','".$father."','".$college."','".$branch."','".$year."','".$grade."','".$event."','".$email."','".$phone."','".$gender."','".$sem."')";*/
$query="insert into csv(usn,name,father,college,branch,year,grade,prize,event,email,phone,gender,sem) values('$usn','$name','$father','$college','$branch','$year','$grade','$rank','$event','$email','$phone','$gender','$sem')";
$res = mysqli_query($conn,$query);
if(mysqli_affected_rows($conn)>0) {
	?><br><br><br>
	<div class="alert alert-success">
  		<strong>Success! Loading...... Please Wait </strong> Your response has been successfully recorded.Thank you.
		<meta http-equiv="refresh" content="3;url=csv.php" />
	</div>

	<?php
}
else
{
	?>
	<br><br><br>
	<div class="alert alert-danger">
  		<strong>Sorry! Loading...... Please Wait </strong> Please try to re enter your details. Please make sure credentials such as id and email are unique
  		<meta http-equiv="refresh" content="4;url=csv.php" />
	</div>
	<?php
}	
}


/*$query="insert into csv(usn,name,father,college,branch,year,grade,rank,event,email,phone,gender,sem) values('$usn','$name','$father','$college','$branch','$year','$grade','$rank','$event','$email','$phone','$gender','$sem')";*/




?>
</body>
</html>