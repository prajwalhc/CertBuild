
<?php
include('../config.php');
?>

<!DOCTYPE html>
<html lang="en">
 <!-- <?php 
//include ('../navbar.php');
  ?>
<head> -->
	<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
   <link rel="stylesheet" href="../css/w3.css">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>    
</head>
 <style type="text/css">
     #page-loader {
position: relative;
top: 0;
bottom: 0;
left: 0;
right: 0;
z-index: 10000;
display: none;
text-align: center;
width: 100%;
padding-top: 25px;
background-color: rgba(255, 255, 255, 0.7);
}
 </style>
 
</head>
 


<body>

 <div id="page-loader">
    <h3 style="color: green;">Loading page...</h3>  
</div><br><br><br>

<div class="row">

<?php
$design=$_GET['design'];

for ($i=1; $i <100; $i++) { 
    if($design==sp.$i)
    {
        ?>
        <div align="center" class="col-sm-6"><a href="../samsport.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
        <?php
        $selected=$design;
        break;
    }
    elseif ($design==cul.$i) {
        ?>
        <div align="center" class="col-sm-6"><a href="../samcul.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
        <?php
        $selected=$design;
        break;

    }
    elseif ($design==course.$i) {
        ?>
        <div align="center" class="col-sm-6"><a href="../samcourse.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
        <?php
        $selected=$design;
        break;
    }
    elseif ($design==bestout.$i) {
        ?>
        <div align="center" class="col-sm-6"><a href="../sambestout.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
        <?php
        $selected=$design;
        break;
    }
     elseif ($design==other.$i) {
        ?>
        <div align="center" class="col-sm-6"><a href="../samother.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
        <?php
        $selected=$design;
        break;
    }
}

 ?>

    <div align="center" class="col-sm-6"><a href="../design.php"><p><button class="btn btn-success btn-lg">Change design</button></p></a></div>
 </div><br>

    <div id="wrap">
        <div class="container">
            <div class="row" style="border:solid thick pink;border-radius: 10px;">
                 <h2><b>Import CSV</b></h2>
                <form class="form-horizontal" action="functions.php" method="post" name="upload_excel" enctype="multipart/form-data">
                    <fieldset>
 
                        <!-- Form Name -->
                        <!-- File Button -->
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="filebutton"><b>Select File</b></label>
                            <div class="col-md-4">
                                <input type="file" name="file" id="file" class="input-large" required="">
                            </div>
                        </div>
 
                        <!-- Button -->
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="singlebutton" >Import data</label>
                            <div class="col-md-4">
                                <button type="submit" id="submit" name="Import" class="btn btn-primary button-loading" data-loading-text="Loading..." ><span class="glyphicon glyphicon-import"></span>Import</button>
                            </div>
                        </div>

                    </fieldset>
                </form>
                    <form class="form-horizontal" action="functions.php" method="post" name="upload_excel"   
                      enctype="multipart/form-data">
                    <div class="form-group">
                            <label class="col-md-4 control-label" for="singlebutton">Export data</label>
                            <div class="col-md-4">
                                <button onClick="javascript: return confirm('Please confirm Export')" type="submit" name="Export" class="btn btn-success button-loading" data-loading-text="Loading..."><span class="glyphicon glyphicon-export"></span>Export</button>
                            </div>
                        </div>     
            </form> 
            			<form class="form-horizontal" action="functions.php" method="post" name="upload_excel"   
                      enctype="multipart/form-data">
            		  <div class="form-group">
                            <label class="col-md-4 control-label" for="singlebutton">Delete data</label>
                            <div class="col-md-4">
                                <button type="submit" id="delete" name="delete" onClick="javascript: return confirm('Please confirm deletion');" class="btn btn-primary button-loading" data-loading-text="Loading..."><span class="glyphicon glyphicon-trash"></span>Delete</button>
                            </div>
                        </div>
                        </form>	
            </div><br>
    
 <div> 		
 	<!-- <div class="row">  -->

        <!-- <div class="col-sm-6"> -->
            
       <!--  </div> -->
   <!--  <div class="col-sm-6"> -->     			
  					<!--  <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo">Simple collapsible</button> -->
                  	<!-- <button class="btn btn-success btn-lg" name="add" id="add" onclick="enabledisable()"><span class="glyphicon glyphicon-plus"></span>Add new student</button>
                  	<script>
							function enabledisable() {
								/*var i;
									for (i = 0; i < 3; i++) {
									  document.getElementById("qw").disabled = false;
									}	*/	
									document.getElementById("usn").disabled = false;
									document.getElementById("name").disabled = false;
									document.getElementById("sem").disabled = false;
									document.getElementById("father").disabled=false;		
									document.getElementById("phone").disabled=false;
									document.getElementById("gender").disabled=false;
									document.getElementById("email").disabled=false;
									document.getElementById("branch").disabled=false;
									document.getElementById("year").disabled=false;
									document.getElementById("college").disabled=false;
									document.getElementById("grade").disabled=false;
									document.getElementById("event").disabled=false;
									document.getElementById("rank").disabled=false;	
									/*document.getElementById("abc").disabled=false;*/
									document.getElementById("usn").focus();		  
							}
				   </script>       -->


       <!--  </div> -->
   <!--  </div> -->           
 </div>

                    <form action="onecsv.php" method="post">
                <button type="button" class="btn btn-info btn-lg" data-toggle="collapse" data-target="#demo"><span class="glyphicon glyphicon-plus"></span>Add new student</button><br><br>
             <div id="demo" class="collapse row">
                <div class="col-sm-2"><input class="form-control input-sm"  type="text" id="usn" name="usn" placeholder=" USN" <?php echo "required='true'";?>></div>
                <div class="col-sm-2"><input class="form-control input-sm" type="text" id="name" name="name" placeholder=" Name" <?php echo "required='true'";?>></div>
              <div class="col-sm-1"><input class="form-control input-sm"  type="text" id="sem" name="sem" placeholder=" Sem" <?php echo "required='true'";?>></div>
              <div class="col-sm-2"><input class="form-control input-sm"  type="text" id="father" name="father" placeholder=" Father" ></div>
               <div class="col-sm-2"><input class="form-control input-sm"  type="text" id="phone" name="phone" placeholder=" phone"></div>
                
               <div class="col-sm-2"><input class="form-control input-sm"  type="text" id="email" name="email" placeholder=" email"></div>
                <div class="col-sm-1"><input class="form-control input-sm"  type="text" id="branch" name="branch" placeholder=" branch" <?php echo "required='true'";?>></div>
                <div class="col-sm-1"><input class="form-control input-sm"  type="text" id="year" name="year" placeholder=" year" <?php echo "required='true'";?>></div>
                <div class="col-sm-2"><input class="form-control input-sm"  type="text" id="college" name="college" placeholder=" college" ></div>
               <div class="col-sm-1"><input class="form-control input-sm"  type="text" id="grade" name="grade" placeholder=" grade"></div>
               <div class="col-sm-2"><input class="form-control input-sm"  type="text" id="event" name="event" placeholder=" event" <?php echo "required='true'";?>></div>
                <div class="col-sm-2"><select name="gender" class="form-control" id="gender" required="">
                    <option value="">Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    </select></div>

                <div class="col-sm-2"><select name="rank" class="form-control" id="rank">
                    <option value="0">Rank</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    </select></div>

               <div class="col-sm-2"><button class="btn btn-success" name="submit" type="submit">Submit</button></div>
                </div>
                </form>
           <div class="table-responsive w3-animate-zoom">
              <table class="table table-striped">
        <thead>
            <tr>
                <th style="color: #FF69B4;"><b>USN</b></th>
                <th  style="color: #FF69B4;"><b>Name</b></th>
                <th style="color: #FF69B4;"><b>Sem</b></th>
                <th style="color: #FF69B4;"><b>Father</b></th>
                <th style="color:#FF69B4;"><b>Phone</b></th>
                <th  style="color: #FF69B4;"><b>Gender</b></th>
                <th  style="color: #FF69B4;"><b>Email</b></th>
                <th  style="color: #FF69B4;"><b>Branch</b></th>
                <th  style="color: #FF69B4;"><b>Year</b></th>
                <th  style="color: #FF69B4;"><b>College</b></th>
                <th  style="color: #FF69B4;"><b>Grade</b></th>
                <th  style="color: #FF69B4;"><b>Event</b></th>
                <th  style="color: #FF69B4;"><b>Rank</b></th>
            </tr>
            <tr><!-- <form action="insertonecsv.php" method="POST">
                <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo">Simple collapsible</button><br/>
             <div id="demo" class="collapse">
                <th style="color: #FF69B4;"><input class="form-control input-sm"  type="text" id="usn" name="usn" disabled></th>
                <th  style="color: #FF69B4;"><input class="form-control input-sm" type="text" id="name" name="name" disabled></th>
                <th style="color: #FF69B4;"><input class="form-control input-sm"  type="text" id="sem" name="sem" disabled></th>
                <th style="color: #FF69B4;"><input class="form-control input-sm"  type="text" id="father" name="father" disabled></th>
                <th style="color: #FF69B4;"><input class="form-control input-sm"  type="text" id="phone" name="phone" disabled></th>
                <th  style="color: #FF69B4;"><input class="form-control input-sm"  type="text" id="gender" name="gender" disabled></th>
                <th  style="color: #FF69B4;"><input class="form-control input-sm"  type="text" id="email" name="email" disabled></th>
                <th  style="color: #FF69B4;"><input class="form-control input-sm"  type="text" id="branch" name="branch" disabled></th>
                <th  style="color: #FF69B4;"><input class="form-control input-sm"  type="text" id="year" name="year" disabled></th>
                <th  style="color: #FF69B4;"><input class="form-control input-sm"  type="text" id="college" name="college" disabled></th>
                <th  style="color: #FF69B4;"><input class="form-control input-sm"  type="text" id="grade" name="grade" disabled></th>
                <th  style="color: #FF69B4;"><input class="form-control input-sm"  type="text" id="event" name="event" disabled></th>
                <th  style="color: #FF69B4;"><input class="form-control input-sm"  type="text" id="rank" name="rank" disabled></th>
                <th ><button class="btn btn-success" id="submit" name="submit" type="submit">Submit</button></th>
                </div>
                </form> -->
            </tr>


            <tbody style="background-color: transparent;">
            <?php 
                /*ini_set('display_errors', 1);
                error_reporting (E_ALL);*/
               include('database.php');
                $sql="select * from csv";
                $result=mysqli_query($conn, $sql);
                if ($result-> num_rows >0) {

                    while ($row= $result-> fetch_assoc()) {
                        echo "<tr><td>".$row["usn"]."</td><td>".$row["name"]."</td><td>".$row["sem"]."</td><td>".$row["father"]."</td><td>".$row["phone"]."</td><td>".$row["gender"]."</td><td>".$row["email"]."</td><td>".$row["branch"]."</td><td>".$row["year"]."</td><td>".$row["college"]."</td><td>".$row["grade"]."</td><td>".$row["event"]."</td><td>".$row["prize"]."</td><td><a href='update.php?usn=".$row["usn"]."' style='color:grey'><span class='glyphicon glyphicon-pencil' style='font-size:19px;'></span></a></td><td><a onClick=\"javascript: return confirm('Please confirm deletion');\" href='delete.php?usn=".$row["usn"]."' style='color:red'><span class='glyphicon glyphicon-trash' style='font-size:19px;'></span></a></td></tr>";
                    }
                    echo "</table>";
                }
                else
                {
                  /*  <td><a onClick=\"javascript: return confirm('Please confirm deletion');\" href='delete.php?id=".$query2['id']."'>x</a></td><tr>"*/
                    echo "0 result"; 
                }
                $conn-> close();
             
             ?>


        </thead>
        </tbody>
    </table>

<?php
for ($i=1; $i <100; $i++) { 
    if($selected==sp.$i)
{
    ?>
    <a href="../printsport<?php echo "$i";?>csv.php"><button class="w3-button w3-blue w3-round-xxlarge" style="float: right; width: 100px">Generate</button></a>
    <?php
    break;
}
 else if($selected==cul.$i)
{
    ?>
    <a href="../printcul<?php echo "$i";?>csv.php"><button class="w3-button w3-blue w3-round-xxlarge" style="float: right; width: 100px">Generate</button></a>
    <?php
    break;
}
else if($selected==course.$i)
{
    ?>
    <a href="../printcourse<?php echo "$i";?>csv.php"><button class="w3-button w3-blue w3-round-xxlarge" style="float: right; width: 100px">Generate</button></a>
    <?php
    break;
}
else if($selected==bestout.$i)
{
    ?>
    <a href="../printbestout<?php echo "$i";?>csv.php"><button class="w3-button w3-blue w3-round-xxlarge" style="float: right; width: 100px">Generate</button></a>
    <?php
    break;
}
else if($selected==other.$i)
{
    ?>
    <a href="../printother<?php echo "$i";?>csv.php"><button class="w3-button w3-blue w3-round-xxlarge" style="float: right; width: 100px">Generate</button></a>
    <?php
    break;
}
}
?>
    </div>


        </div>
    </div>
</body>
 
</html>