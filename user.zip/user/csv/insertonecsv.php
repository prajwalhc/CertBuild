
<?php
ini_set('display_errors', 1);
error_reporting (E_ALL);

$servername ="localhost";
$username= "root";
$password= "Password@123";
$dbname = "certbuild";
$conn = mysqli_connect($servername, $username, $password,$dbname );
if ($conn->connect_error) {
    die("Connection failed: " .mysqli_connect_error());
}

if (isset($_POST['submit'])) {

$usn=strip_tags(($_POST['usn']));
$name =strip_tags(($_POST['name']));
$father =strip_tags(($_POST['father']));
$gender =strip_tags(($_POST['gender']));
$email =strip_tags(($_POST['email']));
$sem=strip_tags(($_POST['sem']));
$phone=strip_tags(($_POST['phone']));
$college =strip_tags(($_POST['college']));
$branch =strip_tags(($_POST['branch']));
$year = strip_tags(($_POST['year']));
$grade =strip_tags(($_POST['grade']));
$event =strip_tags(($_POST['event']));
$rank =strip_tags(($_POST['rank']));
}
$query="insert into csv(usn,name,father,college,branch,year,grade,rank,event,email,phone,gender,sem) values('$usn','$name','$father','$college','$branch','$year','$grade','$rank','$event','$email','$phone','$gender','$sem')";

$res = mysqli_query($conn,$query);
if(mysqli_affected_rows($conn)>0) {
	?><br><br><br>
	<div class="alert alert-success">
  		<strong>Success!</strong> Your response has been successfully recorded.Thank you.
		<meta http-equiv="refresh" content="6;url=index.php" />
	</div>

	<?php
}
else {
	?>
	<br><br><br>
	<div class="alert alert-danger">
  		<strong>Sorry!</strong> Please try to re enter your details. Please make sure credentials such as id and email are unique
  		<meta http-equiv="refresh" content="7;url=csv.php" />
	</div>
	<?php
} 
?>