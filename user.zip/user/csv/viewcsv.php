<!DOCTYPE html>
<html>
<head>
  <title>CertBuilder</title>
  <?php 
include('../navbar.php');
 ?>
</head>
<style type="text/css">


	.bg {
    /* The image used */
    background-image: url("../../img/background7.jpg");

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
</style>


<body class="bg">
<hr class="style1">
<div class="container" style="border:solid thin black;border-radius: 10px;">
  <h2 class="well well-sm" style="background-color:transparent; animation-duration: 3s;text-shadow:1px 1px 0 #444;"><b>CSV Participants Details</b></h2><br>
  <!-- <div style="animation-duration: 3s;" class="w3-animate-zoom">-->
	<div class="table-responsive w3-animate-zoom">
	<table class="table table-striped">
		<thead>
			<tr>
				<th style="color: #FF69B4;"><b>USN</b></th>
				<th  style="color: #FF69B4;"><b>Name</b></th>
				<th style="color: #FF69B4;"><b>Father</b></th>
				<th style="color:#FF69B4;"><b>Phone</b></th>
				<th  style="color: #FF69B4;"><b>Gender</b></th>
				<th  style="color: #FF69B4;"><b>Email</b></th>
				<th  style="color: #FF69B4;"><b>Branch</b></th>
				<th  style="color: #FF69B4;"><b>Year</b></th>
				<th  style="color: #FF69B4;"><b>College</b></th>
				<th  style="color: #FF69B4;"><b>Grade</b></th>
				<th  style="color: #FF69B4;"><b>Event</b></th>
				<th  style="color: #FF69B4;"><b>Rank</b></th>
			</tr>
			<tbody style="background-color: transparent;">
			<?php 
				/*ini_set('display_errors', 1);
				error_reporting (E_ALL);*/
				  include('database.php');

				$sql="select * from csv";
				$result=mysqli_query($conn, $sql);
				if ($result-> num_rows >0) {

					while ($row= $result-> fetch_assoc()) {
						echo "<tr style='background-color:transparent;'><td>".$row["usn"]."</td><td>".$row["name"]."</td><td>".$row["father"]."</td><td>".$row["phone"]."</td><td>".$row["gender"]."</td><td>".$row["email"]."</td><td>".$row["branch"]."</td><td>".$row["year"]."</td><td>".$row["college"]."</td><td>".$row["grade"]."</td><td>".$row["event"]."</td><td>".$row["prize"]."</td></tr>";
					}
					echo "</table>";
				}
				else
				{
					echo "0 result";
				}
				$conn-> close();
			 
			 ?>
		</thead>
		</tbody>
	</table>
	</div>
</div>
</body>
</html>
