<!DOCTYPE html>
<html lang="en">
 <!-- <?php 
//include ('../navbar.php');
  ?>
<head> -->
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
  <link rel="stylesheet" href="../../css/w3.css">
  <script type="text/javascript" src="../../js/bootstrap.min.js"></script>
   <script type="text/javascript" src="../../js/jquery.min.js"></script>
 
 
</head>
 
<body>
    <div id="wrap">
        <div class="container">
            <div class="row">
 
                <form class="form-horizontal" action="functiongec.php" method="post" name="upload_excel" enctype="multipart/form-data">
                    <fieldset>
 
                        <!-- Form Name -->
                        <legend>Import csv</legend>
 
                        <!-- File Button -->
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="filebutton">Select File</label>
                            <div class="col-md-4">
                                <input type="file" name="file" id="file" class="input-large" required="">
                            </div>
                        </div>
 
                        <!-- Button -->
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="singlebutton">Import data</label>
                            <div class="col-md-4">
                                <button type="submit" id="submit" name="Import" class="btn btn-primary button-loading" data-loading-text="Loading..." >Import</button>
                            </div>
                        </div>
 

                         <div class="form-group">
                            <label class="col-md-4 control-label" for="singlebutton">Delete data</label>
                            <div class="col-md-4">
                                <button type="submit" id="delete" name="delete" class="btn btn-primary button-loading" data-loading-text="Loading...">Delete</button>
                            </div>
                        </div>
                    </fieldset>
                </form>
 
            </div>
    
 <div>
            <form class="form-horizontal" action="functions.php" method="post" name="upload_excel"   
                      enctype="multipart/form-data">
                  <div class="form-group">
                            <div class="col-md-4 col-md-offset-4">
                                <input type="submit" name="Export" class="btn btn-success" value="export to excel"/>
                            </div>
                   </div>                    
            </form>           
 </div>

           <div class="table-responsive w3-animate-zoom">
    <table class="table table-striped">
        <thead>
            <tr>
                <th style="color: #FF69B4;"><b>ID</b></th>
                <th  style="color: #FF69B4;"><b>Name</b></th>
                <th style="color: #FF69B4;"><b>Sem</b></th>
                <th style="color:#FF69B4;"><b>Branch</b></th>
                <th  style="color: #FF69B4;"><b>Event</b></th>
                <th  style="color: #FF69B4;"><b>Rank</b></th>
               <!--  <th  style="color: #FF69B4;"><b>Branch</b></th>
                <th  style="color: #FF69B4;"><b>Year</b></th>
                <th  style="color: #FF69B4;"><b>College</b></th>
                <th  style="color: #FF69B4;"><b>Grade</b></th>
                <th  style="color: #FF69B4;"><b>Event</b></th>
                <th  style="color: #FF69B4;"><b>Rank</b></th> -->
            </tr>
            <tbody style="background-color: transparent;">
            <?php 
                ini_set('display_errors', 1);
                error_reporting (E_ALL);
                $servername ="localhost";
                $username= "root";
                $password= "password";
                $dbname = "certbuild";



                $conn = mysqli_connect($servername, $username, $password,$dbname );
                if ($conn->connect_error) {
                die("Connection failed: ");
                }

                $sql="select * from gechutsav";
                $result=mysqli_query($conn, $sql);
                if ($result-> num_rows >0) {

                    while ($row= $result-> fetch_assoc()) {
                        echo "<tr><td>".$row["id"]."</td><td>".$row["name"]."</td><td>".$row["sem"]."</td><td>".$row["branch"]."</td><td>".$row["event"]."</td><td>".$row["rank"]."</td><td><a href='update.php?usn=".$row["id"]."' style='color:grey'><span class='glyphicon glyphicon-pencil' style='font-size:19px;'></span></a></td><td><a onClick=\"javascript: return confirm('Please confirm deletion');\" href='delete.php?usn=".$row["id"]."' style='color:red'><span class='glyphicon glyphicon-trash' style='font-size:19px;'></span></a></td></tr>";
                    }
                    echo "</table>";
                }
                else
                {
                  /*  <td><a onClick=\"javascript: return confirm('Please confirm deletion');\" href='delete.php?id=".$query2['id']."'>x</a></td><tr>"*/
                    echo "0 result"; 
                }
                $conn-> close();
             
             ?>


        </thead>
        </tbody>
    </table>


        </div>
        <div align="center">
          <a href="../printgeccul.php"><button type="button" class="btn btn-primary btn-lg" style="">Generate Cultural</button></a>
      <a href="../printgecsport.php"><button type="button" class="btn btn-success btn-lg" style="" >Generate Sport</button></a>
      </div>
    </div>
</body>
 
</html>
