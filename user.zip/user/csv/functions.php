<?php 
include('database.php');

try {
   
    $conn = mysqli_connect($servername, $username, $password, $db);


    if(isset($_POST["Import"])){
    	$sql="truncate table csv";
	mysqli_query($conn,$sql);
		
		$filename=$_FILES["file"]["tmp_name"];		


		 if($_FILES["file"]["size"] > 0)
		 {
		  	$file = fopen($filename, "r");
	        while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
	         {


	           $sql = "INSERT into csv(usn,name,father,college,branch,gender,year,grade,prize,event,email,phone,sem) 
                   values ('".$getData[0]."','".$getData[1]."','".$getData[2]."','".$getData[3]."','".$getData[4]."','".$getData[5]."','".$getData[6]."','".$getData[7]."','".$getData[8]."','".$getData[9]."','".$getData[10]."','".$getData[11]."','".$getData[12]."')";
                   $result = mysqli_query($conn, $sql);
				if(!isset($result))
				{
					echo "<script type=\"text/javascript\">
							alert(\"Invalid File:Please Upload CSV File.\");
							window.location = \"csv.php\"
						  </script>";		
				}
				else {
					  echo "<script type=\"text/javascript\">
						alert(\"CSV File has been successfully Imported.\");
						window.location = \"csv.php\"
					</script>";
				}
	         }
			
	         fclose($file);	
		 }
	}



 if(isset($_POST["delete"])){
 			$sql = "truncate table csv";
 			$res = mysqli_query($conn,$sql);
 			if($result-> num_rows >0) {
	?><br><br><br>
	<div class="alert alert-success">
  		<strong>Deleted!</strong>Successfully
		<meta http-equiv="refresh" content="3;url=csv.php" />
	</div>

	<?php
}
else {
	?>
	<br><br><br>
	<div class="alert alert-danger">
  		<strong>Sorry!</strong>Data not deleted Or Nothing to Delete.
  		<meta http-equiv="refresh" content="2;url=csv.php" />
	</div>
	<?php
} 
 }
   if(isset($_POST["Export"])){
		 
      header('Content-Type: text/csv; charset=utf-8');  
      header('Content-Disposition: attachment; filename=data.csv');  
      $output = fopen("php://output", "w");  
      fputcsv($output, array('usn', 'Name', 'father', 'college', 'branch','gender','year','grade','rank','event','email','phone','sem'));  
      $query = "SELECT usn,name,father,college,branch,gender,year,grade,prize,event,email,phone,sem from csv  ORDER BY usn DESC";  
      $result = mysqli_query($conn, $query);
      
         
      while($row = mysqli_fetch_assoc($result))  
      {  
           fputcsv($output, $row);  
      }  
      fclose($output);

 }  
}
catch(exception $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }
?>